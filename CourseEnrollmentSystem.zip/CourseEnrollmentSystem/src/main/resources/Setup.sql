-- Create Database;
CREATE DATABASE IF NOT EXISTS course_enroll;
drop database course_enroll;
-- Use the created database
USE course_enroll;


-- ========================  Admins table  ==================================
CREATE TABLE IF NOT EXISTS admins (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone_number VARCHAR(20) NOT NULL
);
USE course_enroll;
DELETE FROM admins WHERE id = 3;


-- =====================  Courses table  ====================================

CREATE TABLE IF NOT EXISTS courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) UNIQUE NOT NULL,
    description TEXT NOT NULL,
    fee DOUBLE NOT NULL,
    duration INT NOT NULL
);

ALTER TABLE courses AUTO_INCREMENT = 1;

drop table course;

CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
	password VARCHAR(100) NOT NULL,
    phoneNumber VARCHAR(10) NOT NULL CHECK (LENGTH(phoneNumber) = 10 AND phoneNumber REGEXP '^[0-9]{10}$'),
    enrolled_course_id INT,
    FOREIGN KEY (enrolled_course_id) REFERENCES courses(id)
);
drop table students;


-- ===================== enrollments ===================================

CREATE TABLE enrollments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT,
    course_id INT,
    course_name VARCHAR(255),  -- Add course_name to track the course name
    payment_method VARCHAR(50),
    enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
);

ALTER TABLE enrollments ADD COLUMN fees_paid DECIMAL(10,2) DEFAULT 0.00;


drop table enrollments;

-- =======================  Feedback table  ===================================


CREATE TABLE IF NOT EXISTS feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    course_id INT,
    rating INT CHECK (rating >= 1 AND rating <= 5),
    comments TEXT,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)

);

-- ===========================  payments  ====================================

 CREATE TABLE IF NOT EXISTS payments (
     id INT AUTO_INCREMENT PRIMARY KEY,
     student_id INT,
     course_id INT,
     payment_method VARCHAR(50),
     payment_status ENUM('Pending', 'Completed', 'Failed') DEFAULT 'Pending',
     transaction_id VARCHAR(255) UNIQUE,
     payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     FOREIGN KEY (student_id) REFERENCES students(id),
     FOREIGN KEY (course_id) REFERENCES courses(id)
 );
-- drop table payments;



--SELECT s.name, s.email, c.name AS course_name
--FROM students s
--JOIN enrollments e ON s.id = e.student_id  -- Change student_id to id
--JOIN courses c ON e.course_id = c.id;





-- ===================  Users table  =======================================
-- CREATE TABLE IF NOT EXISTS users (
--     id INT AUTO_INCREMENT PRIMARY KEY,
--     username VARCHAR(50) NOT NULL,
--     password VARCHAR(50) NOT NULL,
--     name VARCHAR(100),
--     email VARCHAR(100),
--     role ENUM('admin', 'student') NOT NULL
-- );

-- drop table users;

-- SELECT s.name, s.email, c.name AS name
-- FROM students s
-- JOIN enrollments e ON s.id = e.student_id
-- JOIN courses c ON e.course_id = c.id;

-- ========================================================================= --


